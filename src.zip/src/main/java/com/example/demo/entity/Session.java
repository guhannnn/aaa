package com.example.demo.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Session {
@Id
private int cid;
private String aid;
private int bookingid;
private String mode;
private String dateandtime;
private String duration;
private String slot;
private String review;
public Session() {
	super();
	// TODO Auto-generated constructor stub
}
public Session(int cid, String aid, int bookingid, String mode, String dateandtime, String duration,
		String slot, String review) {
	super();
	this.cid = cid;
	this.aid = aid;
	this.bookingid = bookingid;
	this.mode = mode;
	this.dateandtime = dateandtime;
	this.duration = duration;
	this.slot = slot;
	this.review = review;
}
public int getId() {
	return cid;
}
public void setId(int cid) {
	this.cid = cid;
}
public String getaid() {
	return aid;
}
public void setaid(String aid) {
	this.aid = aid;
}
public int getbookingid() {
	return bookingid;
}
public void setbookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getmode() {
	return mode;
}
public void setmode(String mode) {
	this.mode = mode;
}
public String getdateandtime() {
	return dateandtime;
}
public void setdateandtime(String dateandtime) {
	this.dateandtime = dateandtime;
}
public String getduration() {
	return duration;
}
public void setduration(String duration) {
	this.duration = duration;
}
public String getslot() {
	return slot;
}
public void setslot(String slot) {
	this.slot = slot;
}
public String getReview() {
	return review;
}
public void setReview(String review) {
	this.review = review;
}


}