package com.example.demo.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Payment {
	
@Id

private int cid;
private String aid;
private int bookingid;
private String paymentType;
private String paymentStatus;

public Payment() {
	super();
	// TODO Auto-generated constructor stub
}

public Payment(int cid, String aid, int bookingid, String paymentType, String paymentStatus, String price,String slot) 
{
	super();
	this.cid = cid;
	this.aid = aid;
	this.bookingid = bookingid;
	this.paymentType = paymentType;
	this.paymentStatus = paymentStatus;
}

public int getId() {
	return cid;
}
public void setId(int cid) {
	this.cid = cid;
}
public String getaid() {
	return aid;
}
public void setaid(String aid) {
	this.aid = aid;
}
public int getbookingid() {
	return bookingid;
}
public void setbookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getpaymentType() {
	return paymentType;
}
public void setpaymentType(String paymentType) {
	this.paymentType = paymentType;
}
public String getpaymentStatus() {
	return paymentStatus;
}
public void setpaymentStatus(String paymentStatus) {
	this.paymentStatus = paymentStatus;
}



}