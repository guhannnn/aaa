package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Advisor {
@Id
private int id;
private String name;
private int email;
private String phone;
private String password;
public Advisor() {
}
public Advisor(int id,String name, int email, String phone, String password) {

this.id = id;	
this.name = name;
this.email = email;
this.phone = phone;
this.password = password;
}
// getters and setters
public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public int getemail() {
return email;
}
public void setemail(int email) {
this.email = email;
}
public String getphone() {
return phone;
}
public void setphone(String phone) {
this.phone = phone;
}
public String getpassword() {
return password;
}
public void setpassword(String password) {
this.password = password;
}
}
