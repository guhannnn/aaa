package com.example.demo.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Account {
@Id
private int id;
private String areaofEx;
private int qualification;
private String type;
private String focus;
private String location;
private String language;
public Account() {
	super();
	// TODO Auto-generated constructor stub
}
public Account(int id, String areaofEx, int qualification, String type, String focus, String location,
		String language) {
	super();
	this.id = id;
	this.areaofEx = areaofEx;
	this.qualification = qualification;
	this.type = type;
	this.focus = focus;
	this.location = location;
	this.language = language;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAreaofEx() {
	return areaofEx;
}
public void setAreaofEx(String areaofEx) {
	this.areaofEx = areaofEx;
}
public int getQualification() {
	return qualification;
}
public void setQualification(int qualification) {
	this.qualification = qualification;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getFocus() {
	return focus;
}
public void setFocus(String focus) {
	this.focus = focus;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getLanguage() {
	return language;
}
public void setLanguage(String language) {
	this.language = language;
}


}