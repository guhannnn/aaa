package com.example.demo.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class AdvisorProfile {
@Id
private int id;
private String achievements;
private int consultingRate;
private String lang;
private String loc;
private String availablity;
private String offerings;
public AdvisorProfile() {
	super();
	// TODO Auto-generated constructor stub
}
public AdvisorProfile(int id, String achievements, int consultingRate, String lang, String loc, String availablity,
		String offerings) {
	super();
	this.id = id;
	this.achievements = achievements;
	this.consultingRate = consultingRate;
	this.lang = lang;
	this.loc = loc;
	this.availablity = availablity;
	this.offerings = offerings;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getachievements() {
	return achievements;
}
public void setachievements(String achievements) {
	this.achievements = achievements;
}
public int getconsultingRate() {
	return consultingRate;
}
public void setconsultingRate(int consultingRate) {
	this.consultingRate = consultingRate;
}
public String getlang() {
	return lang;
}
public void setlang(String lang) {
	this.lang = lang;
}
public String getloc() {
	return loc;
}
public void setloc(String loc) {
	this.loc = loc;
}
public String getavailablity() {
	return availablity;
}
public void setavailablity(String availablity) {
	this.availablity = availablity;
}
public String getofferings() {
	return offerings;
}
public void setofferings(String offerings) {
	this.offerings = offerings;
}


}