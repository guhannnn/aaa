package com.example.demo.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Booking {
@Id
private int cid;
private String aid;
private int bookingid;
private String mode;
private String dateandtime;
private String price;
private String slot;
public Booking() {
	super();
	// TODO Auto-generated constructor stub
}
public Booking(int cid, String aid, int bookingid, String mode, String dateandtime, String price,
		String slot) {
	super();
	this.cid = cid;
	this.aid = aid;
	this.bookingid = bookingid;
	this.mode = mode;
	this.dateandtime = dateandtime;
	this.price = price;
	this.slot = slot;
}
public int getId() {
	return cid;
}
public void setId(int cid) {
	this.cid = cid;
}
public String getaid() {
	return aid;
}
public void setaid(String aid) {
	this.aid = aid;
}
public int getbookingid() {
	return bookingid;
}
public void setbookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getmode() {
	return mode;
}
public void setmode(String mode) {
	this.mode = mode;
}
public String getdateandtime() {
	return dateandtime;
}
public void setdateandtime(String dateandtime) {
	this.dateandtime = dateandtime;
}
public String getprice() {
	return price;
}
public void setprice(String price) {
	this.price = price;
}
public String getslot() {
	return slot;
}
public void setslot(String slot) {
	this.slot = slot;
}


}