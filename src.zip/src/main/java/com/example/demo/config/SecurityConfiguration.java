//package com.example.demo.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import lombok.RequiredArgsConstructor;
//import org.springframework.demo.config.annotation.web.builders.Httpdemo;
//import org.springframework.demo.config.annotation.web.configuration.EnableWebdemo;
//import org.springframework.demo.config.http.SessionCreationPolicy;
//import org.springframework.demo.web.demoFilterChain;
//import org.springframework.demo.web.authentication.UsernamePasswordAuthenticationFilter;
//
//@Configuration
//@EnableWebdemo
//@RequiredArgsConstructor
//public class demoConfiguration {
//
//    private final JwtAuthenticationFilter jwtAuthFilter;
//    private final AuthenticationProvider authenticationProvider;
//
//    @Bean
//    public demoFilterChain demoFilterChain(Httpdemo httpdemo) throws Exception {
//        httpdemo
//                .csrf()
//                .disable()
//                .authorizeHttpRequests()
//                .requestMatchers("/api/v1/auth/**")
//                .permitAll()
//                .anyRequest()
//                .authenticated()
//                .and()
//                .sessionManagement()
//                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//                .and()
//                .authenticationProvider(authenticationProvider) 
//                                                                
//                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class); 
//        return httpdemo.build();
//    }
//}
